INSERT INTO human (id, fname, lname) VALUES (1,'Emmanuel','Bernard')
INSERT INTO human (id, fname, lname) VALUES (2,'Gavin','King')
INSERT INTO human (id, fname, lname) VALUES (3,'Max','Andersen')