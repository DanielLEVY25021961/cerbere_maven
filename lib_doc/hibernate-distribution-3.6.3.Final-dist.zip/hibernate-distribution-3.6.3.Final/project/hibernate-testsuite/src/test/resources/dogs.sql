INSERT INTO dog (id, master_fk) VALUES (1,1)
INSERT INTO dog (id, master_fk) VALUES (2,2)
INSERT INTO dog (id, master_fk) VALUES (3,3)