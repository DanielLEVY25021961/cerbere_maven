// $Id: Car.java 7087 2005-06-08 18:23:44Z steveebersole $
package org.hibernate.test.entityname;

/**
 * Implementation of Car.
 *
 * @author Steve Ebersole
 */
public class Car extends Vehicle {
}
