package org.hibernate.test.usercollection.basic;

import java.util.List;

public interface IMyList extends List {

}
