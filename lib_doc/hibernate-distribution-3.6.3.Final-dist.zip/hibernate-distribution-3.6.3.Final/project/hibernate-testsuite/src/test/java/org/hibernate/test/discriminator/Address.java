//$Id: Address.java 4373 2004-08-18 09:18:34Z oneovthafew $
package org.hibernate.test.discriminator;

/**
 * @author Gavin King
 */
public class Address {
	public String address;
	public String zip;
	public String country;
}
