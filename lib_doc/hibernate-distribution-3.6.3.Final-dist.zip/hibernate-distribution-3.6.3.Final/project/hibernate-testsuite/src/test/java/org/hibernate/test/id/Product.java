//$Id: $
package org.hibernate.test.id;

/**
 * @author Emmanuel Bernard
 */
public class Product {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
